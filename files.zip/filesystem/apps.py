from django.apps import AppConfig


class FilesystemConfig(AppConfig):
    name = 'filesystem'
